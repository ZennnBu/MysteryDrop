# MysteryDrop

MysteryDrop is a lightweight Paper plugin for Minecraft 1.21.4. It spawns loot chests with configurable item rewards, particles, sounds, and announcements. No Vault or economy plugin is required.

## Commands
- `/mysterydrop spawn` — spawn a chest near the command executor (players) or around world spawn (console)
- `/mysterydrop start` — start automatic drops
- `/mysterydrop stop` — stop automatic drops
- `/mysterydrop reload` — reload configuration
- `/mysterydrop help` — show commands

Permission: `mysterydrop.admin` (default: OP)

## Build
Java 21 and Gradle; Paper API 1.21.4.

## Rewards
Configure `rewards.items` in `config.yml` using `MATERIAL:amount`, one entry per line.
