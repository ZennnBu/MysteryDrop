package com.mysterydrop;


import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.HashSet;


public final class MysteryDrop extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final Random random = new Random();
    private BukkitTask autoTask;
    private BukkitTask countdownTask;
    private final Set<Location> activeDrops = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("mysterydrop") != null) {
            getCommand("mysterydrop").setExecutor(this);
            getCommand("mysterydrop").setTabCompleter(this);
        }
        if (getConfig().getBoolean("drop.auto-start", false)) startAutoDrops();
        getLogger().info("MysteryDrop enabled.");
    }


    @Override
    public void onDisable() {
        stopAutoDrops();
        if (countdownTask != null) countdownTask.cancel();
    }


    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mysterydrop.admin")) {
            sendMessage(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "spawn" -> {
                Location origin = sender instanceof Player player ? player.getLocation() : null;
                Location drop = spawnDrop(origin);
                if (drop != null) sendMessage(sender, "spawned");
            }
            case "start" -> {
                if (autoTask != null) sendMessage(sender, "already-running");
                else { startAutoDrops(); sendMessage(sender, "started"); }
            }
            case "stop" -> {
                if (autoTask == null && countdownTask == null) sendMessage(sender, "not-running");
                else { stopAutoDrops(); sendMessage(sender, "stopped"); }
            }
            case "reload" -> {
                reloadConfig();
                if (getConfig().getBoolean("drop.auto-start", false) && autoTask == null) startAutoDrops();
                sendMessage(sender, "reloaded");
            }
            case "help" -> sendHelp(sender);
            default -> sendHelp(sender);
        }
        return true;
    }


    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> options = List.of("spawn", "start", "stop", "reload", "help");
            String prefix = args[0].toLowerCase(Locale.ROOT);
            List<String> matches = new ArrayList<>();
            for (String option : options) if (option.startsWith(prefix)) matches.add(option);
            return matches;
        }
        return Collections.emptyList();
    }


    private void startAutoDrops() {
        stopAutoDrops();
        long intervalMinutes = Math.max(1, getConfig().getLong("drop.interval-minutes", 30));
        long intervalTicks = intervalMinutes * 60L * 20L;
        autoTask = new BukkitRunnable() {
            @Override public void run() { beginCountdownAndDrop(); }
        }.runTaskTimer(this, intervalTicks, intervalTicks);
    }


    private void stopAutoDrops() {
        if (autoTask != null) { autoTask.cancel(); autoTask = null; }
        if (countdownTask != null) { countdownTask.cancel(); countdownTask = null; }
    }


    private void beginCountdownAndDrop() {
        if (countdownTask != null) countdownTask.cancel();
        int seconds = Math.max(0, getConfig().getInt("drop.countdown-seconds", 10));
        if (seconds <= 0) { spawnDrop(null); return; }
        countdownTask = new BukkitRunnable() {
            int remaining = seconds;
            @Override public void run() {
                if (remaining <= 0) {
                    spawnDrop(null);
                    countdownTask = null;
                    cancel();
                    return;
                }
                if (remaining <= 10 || remaining % 30 == 0) broadcast("countdown", "{seconds}", String.valueOf(remaining));
                remaining--;
            }
        }.runTaskTimer(this, 0L, 20L);
    }


    private Location spawnDrop(Location playerOrigin) {
        String worldName = getConfig().getString("drop.world", "world");
        World world = playerOrigin != null ? playerOrigin.getWorld() : Bukkit.getWorld(worldName);
        if (world == null) {
            broadcastRaw(getConfig().getString("messages.no-world", "&cConfigured world could not be found."));
            return null;
        }
        int configuredRadius = Math.max(0, getConfig().getInt("drop.radius", 500));
        int radius = playerOrigin != null ? Math.min(configuredRadius, 5) : configuredRadius;
        Location center = playerOrigin != null ? playerOrigin : world.getSpawnLocation();
        int x = center.getBlockX() + (radius == 0 ? 0 : random.nextInt(radius * 2 + 1) - radius);
        int z = center.getBlockZ() + (radius == 0 ? 0 : random.nextInt(radius * 2 + 1) - radius);
        int y = world.getHighestBlockYAt(x, z) + 1;
        if (y >= world.getMaxHeight()) y = world.getMaxHeight() - 2;
        Location location = new Location(world, x, y, z);
        Block block = location.getBlock();
        if (!block.isEmpty() && !block.isLiquid()) {
            y++;
            if (y >= world.getMaxHeight() - 1) return null;
            location.setY(y);
            block = location.getBlock();
        }
        if (!block.isEmpty()) block.setType(Material.AIR);
        block.setType(Material.CHEST);
        BlockState state = block.getState();
        if (!(state instanceof Chest chest)) return null;
        Location key = block.getLocation();
        fillChest(chest.getBlockInventory());
        if (!chest.update(true, false)) getLogger().warning("Could not update MysteryDrop chest state at " + key);
        activeDrops.add(key);
        world.spawnParticle(org.bukkit.Particle.END_ROD, location.clone().add(0.5, 1.0, 0.5), 40, 0.5, 0.8, 0.5, 0.02);
        world.spawnParticle(org.bukkit.Particle.HAPPY_VILLAGER, location.clone().add(0.5, 1.0, 0.5), 24, 0.5, 0.5, 0.5);
        world.playSound(location, org.bukkit.Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1f);
        String message = getConfig().getString("messages.drop", "&eMysteryDrop appeared at {x}, {y}, {z}!");
        message = message.replace("{x}", String.valueOf(x)).replace("{y}", String.valueOf(y)).replace("{z}", String.valueOf(z)).replace("{world}", world.getName());
        broadcastRaw(message);
        long lifetime = Math.max(0, getConfig().getLong("drop.chest-lifetime-minutes", 30));
        if (lifetime > 0) Bukkit.getScheduler().runTaskLater(this, () -> removeDropIfEmpty(key), lifetime * 60L * 20L);
        return location;
    }


    private void fillChest(Inventory inventory) {
        inventory.clear();
        List<String> rewards = getConfig().getStringList("rewards.items");
        if (rewards.isEmpty()) {
            inventory.setItem(0, new ItemStack(Material.DIAMOND, 3));
            inventory.setItem(1, new ItemStack(Material.GOLDEN_APPLE, 2));
            getLogger().warning("rewards.items is empty; added fallback rewards.");
            return;
        }

        int slot = 0;
        for (String entry : rewards) {
            if (slot >= inventory.getSize()) {
                getLogger().warning("MysteryDrop chest is full; skipped reward: " + entry);
                continue;
            }
            String[] parts = entry.split(":", 2);
            Material material = Material.matchMaterial(parts[0].trim());
            if (material == null || material.isAir()) {
                getLogger().warning("Unknown reward material: " + entry);
                continue;
            }
            int amount = 1;
            if (parts.length > 1) {
                try { amount = Integer.parseInt(parts[1].trim()); }
                catch (NumberFormatException ignored) {
                    getLogger().warning("Invalid reward amount: " + entry);
                    continue;
                }
            }
            if (amount <= 0) {
                getLogger().warning("Invalid non-positive reward amount: " + entry);
                continue;
            }
            int max = material.getMaxStackSize();
            while (amount > 0 && slot < inventory.getSize()) {
                int stackAmount = Math.min(amount, max);
                inventory.setItem(slot++, new ItemStack(material, stackAmount));
                amount -= stackAmount;
            }
            if (amount > 0) getLogger().warning("Chest full; remaining amount skipped for: " + entry);
        }
        getLogger().info("Filled MysteryDrop chest with " + slot + " reward stack(s).");
    }

    @EventHandler
    public void onChestBreak(BlockBreakEvent event) {
        Location key = event.getBlock().getLocation();
        activeDrops.remove(key);
    }


    private void removeDropIfEmpty(Location location) {
        Block block = location.getBlock();
        if (block.getType() != Material.CHEST) { activeDrops.remove(location); return; }
        BlockState state = block.getState();
        if (state instanceof Chest chest && chest.getBlockInventory().isEmpty()) {
            block.setType(Material.AIR);
            activeDrops.remove(location);
        }
    }


    private void sendHelp(CommandSender sender) {
        for (String line : getConfig().getStringList("messages.help")) sender.sendMessage(color(line));
    }


    private void sendMessage(CommandSender sender, String key) {
        sender.sendMessage(color(getConfig().getString("messages.prefix", "&6MysteryDrop &8» &r") + getConfig().getString("messages." + key, "&cMessage missing: " + key)));
    }


    private void broadcast(String key, String placeholder, String value) {
        String message = getConfig().getString("messages." + key, "&eMysteryDrop: " + placeholder + "!");
        broadcastRaw(message.replace(placeholder.replace("{seconds}", "{seconds}"), value).replace("{seconds}", value));
    }


    private void broadcastRaw(String message) {
        Bukkit.broadcastMessage(color(getConfig().getString("messages.prefix", "&6MysteryDrop &8» &r") + message));
    }


    private String color(String text) { return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text); }
}
