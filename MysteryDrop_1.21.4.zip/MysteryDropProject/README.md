# MysteryDrop

MysteryDrop is a lightweight Paper plugin for Minecraft 1.21.4 that creates loot chests with particles and broadcasts.


## Requirements
- Paper 1.21.4
- Java 21


## Commands
- `/mysterydrop spawn` — spawn a chest near your current location (players) or around world spawn (console)
- `/mysterydrop start` — begin scheduled drops
- `/mysterydrop stop` — stop scheduled drops/countdown
- `/mysterydrop reload` — reload config
- `/mysterydrop help` — list commands


Permission: `mysterydrop.admin` (default OP)

## Build
Run `gradle build` with Java 21. The jar is in `build/libs/`.


## Configuration
See `src/main/resources/config.yml`. Vault money rewards are optional and use reflection; install Vault and an economy provider, then set `rewards.money` to a positive value.
