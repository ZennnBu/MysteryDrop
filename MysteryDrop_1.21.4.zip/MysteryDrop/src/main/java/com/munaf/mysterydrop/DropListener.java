package com.munaf.mysterydrop;


import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.InventoryHolder;

public class DropListener implements Listener {
    private final MysteryDropPlugin plugin;
    public DropListener(MysteryDropPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onChestOpen(InventoryOpenEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof Chest chest)) return;
        Location loc = chest.getBlock().getLocation();
        if (plugin.isActiveChest(loc)) plugin.claimMoney(player, loc);
    }

    @EventHandler
    public void onChestBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (block.getType() != Material.CHEST) return;
        Location loc = block.getLocation();
        if (!plugin.isActiveChest(loc)) return;
        // Keep drops normal; mark the special chest inactive to avoid duplicate cash claims.
        plugin.removeDropForBreak(loc);
    }
}
