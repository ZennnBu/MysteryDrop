package com.munaf.mysterydrop;


import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import org.bukkit.Particle;
import org.bukkit.Sound;

import java.util.*;


public class MysteryDropPlugin extends JavaPlugin {
    private final Random random = new Random();
    private BukkitTask autoTask;
    private BukkitTask countdownTask;
    private BukkitTask effectTask;
    private Economy economy;
    private final Set<Location> activeChests = new HashSet<>();
    private final Set<Location> moneyClaimed = new HashSet<>();
    private int countdownRemaining;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        setupEconomy();
        getServer().getPluginManager().registerEvents(new DropListener(this), this);
        if (getConfig().getBoolean("settings.auto-start", true)) startAutomatic();
        getLogger().info("MysteryDrop enabled.");
    }

    @Override
    public void onDisable() {
        cancelTasks();
    }

    private void setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) return;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) economy = rsp.getProvider();
        if (economy == null) getLogger().warning("Vault economy not found. Money rewards are disabled.");
    }


    private String msg(String key) {
        return color(getConfig().getString("messages." + key, ""));
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }


    private void send(CommandSender sender, String key) {
        sender.sendMessage(color(getConfig().getString("messages.prefix", "") + getConfig().getString("messages." + key, "")));
    }


    private void broadcast(String key) {
        Bukkit.broadcastMessage(color(getConfig().getString("messages.prefix", "") + getConfig().getString("messages." + key, "")));
    }


    private void startAutomatic() {
        stopAutomatic();
        int interval = Math.max(1, getConfig().getInt("settings.interval-minutes", 20));
        int countdown = Math.max(0, getConfig().getInt("settings.countdown-seconds", 10));
        autoTask = Bukkit.getScheduler().runTaskTimer(this, () -> beginCountdown(countdown), 20L, interval * 60L * 20L);
        broadcast("started");
    }


    private void stopAutomatic() {
        if (autoTask != null) autoTask.cancel();
        autoTask = null;
        if (countdownTask != null) countdownTask.cancel();
        countdownTask = null;
    }


    private void beginCountdown(int seconds) {
        if (countdownTask != null) countdownTask.cancel();
        if (seconds <= 0) {
            spawnDrop();
            return;
        }
        countdownRemaining = seconds;
        countdownTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (countdownRemaining <= 0) {
                countdownTask.cancel();
                countdownTask = null;
                spawnDrop();
                return;
            }
            if (countdownRemaining == seconds || countdownRemaining <= 5) {
                String message = getConfig().getString("messages.countdown", "").replace("{seconds}", String.valueOf(countdownRemaining));
                Bukkit.broadcastMessage(color(getConfig().getString("messages.prefix", "") + message));
                for (Player p : Bukkit.getOnlinePlayers()) p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.7f, 1.4f);
            }
            countdownRemaining--;
        }, 0L, 20L);
    }


    private World getDropWorld() {
        String configured = getConfig().getString("settings.world", "").trim();
        if (!configured.isEmpty()) return Bukkit.getWorld(configured);
        return Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0);
    }


    private Location randomDropLocation(World world) {
        Location center = world.getSpawnLocation();
        int radius = Math.max(20, getConfig().getInt("settings.radius", 350));
        for (int attempt = 0; attempt < 30; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double distance = Math.sqrt(random.nextDouble()) * radius;
            int x = center.getBlockX() + (int) Math.round(Math.cos(angle) * distance);
            int z = center.getBlockZ() + (int) Math.round(Math.sin(angle) * distance);
            int y = world.getHighestBlockYAt(x, z) + 1;
            Location loc = new Location(world, x, y, z);
            if (loc.getBlock().isEmpty() && loc.clone().add(0, 1, 0).getBlock().isEmpty()) return loc;
        }
        int x = center.getBlockX();
        int z = center.getBlockZ();
        return new Location(world, x, world.getHighestBlockYAt(x, z) + 1, z);
    }


    public void spawnDrop() {
        World world = getDropWorld();
        if (world == null) {
            broadcast("no-world");
            return;
        }
        Location location = randomDropLocation(world);
        Block block = location.getBlock();
        block.setType(Material.CHEST);
        if (!(block.getState() instanceof Chest chest)) return;
        Inventory inv = chest.getBlockInventory();
        fillLoot(inv);
        String name = color(getConfig().getString("settings.chest-name", "&6&lMystery Drop"));
        ItemStack display = new ItemStack(Material.CHEST);
        ItemMeta meta = display.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            display.setItemMeta(meta);
        }
        chest.setCustomName(name);
        chest.update();
        Location key = block.getLocation();
        activeChests.add(key);
        moneyClaimed.remove(key);
        if (getConfig().getBoolean("settings.chest-glow", true)) block.getWorld().spawnParticle(Particle.END_ROD, location.clone().add(0.5, 1.1, 0.5), 35, 0.45, 0.7, 0.45, 0.03);
        block.getWorld().playSound(location, Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1.0f);
        if (getConfig().getBoolean("settings.broadcast-coordinates", true)) {
            String message = getConfig().getString("messages.spawned", "").replace("{x}", String.valueOf(location.getBlockX())).replace("{y}", String.valueOf(location.getBlockY())).replace("{z}", String.valueOf(location.getBlockZ()));
            Bukkit.broadcastMessage(color(getConfig().getString("messages.prefix", "") + message));
        } else broadcast("spawned");
        startEffects(key);
        int removeMinutes = Math.max(1, getConfig().getInt("settings.remove-after-minutes", 5));
        Bukkit.getScheduler().runTaskLater(this, () -> removeDrop(key), removeMinutes * 60L * 20L);
    }


    private void fillLoot(Inventory inventory) {
        ConfigurationSection root = getConfig().getConfigurationSection("loot");
        if (root == null) return;
        for (Map<?, ?> entry : getConfig().getMapList("loot")) {
            Object materialObj = entry.get("material");
            if (materialObj == null) continue;
            Material material = Material.matchMaterial(String.valueOf(materialObj));
            if (material == null || !material.isItem()) continue;
            double chance = 1.0;
            Object chanceObj = entry.get("chance");
            if (chanceObj instanceof Number n) chance = n.doubleValue();
            if (random.nextDouble() > Math.max(0, Math.min(1, chance))) continue;
            int amount = 1;
            Object amountObj = entry.get("amount");
            if (amountObj instanceof Number n) amount = n.intValue();
            amount = Math.max(1, Math.min(material.getMaxStackSize(), amount));
            ItemStack item = new ItemStack(material, amount);
            inventory.addItem(item);
        }
    }


    private void startEffects(Location chestLoc) {
        if (effectTask != null) effectTask.cancel();
        effectTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!activeChests.contains(chestLoc)) {
                effectTask.cancel();
                effectTask = null;
                return;
            }
            Location particleLoc = chestLoc.clone().add(0.5, 1.0, 0.5);
            chestLoc.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, particleLoc, 4, 0.4, 0.4, 0.4, 0.01);
        }, 0L, 20L);
    }


    private void removeDrop(Location loc) {
        if (!activeChests.remove(loc)) return;
        moneyClaimed.remove(loc);
        Block block = loc.getBlock();
        if (block.getType() == Material.CHEST) {
            block.getWorld().spawnParticle(Particle.SMOKE, loc.clone().add(0.5, 0.5, 0.5), 12, 0.3, 0.3, 0.3, 0.02);
            block.setType(Material.AIR);
        }
    }


    public boolean isActiveChest(Location loc) {
        return activeChests.contains(loc);
    }

    public void removeDropForBreak(Location loc) {
        activeChests.remove(loc);
        moneyClaimed.remove(loc);
    }


    public boolean claimMoney(Player player, Location chestLocation) {
        if (!activeChests.contains(chestLocation)) return false;
        double amount = getConfig().getDouble("settings.money-reward", 0.0);
        if (amount <= 0 || economy == null) {
            player.sendMessage(color(getConfig().getString("messages.prefix", "") + getConfig().getString("messages.money-disabled", "")));
            return true;
        }
        if (!moneyClaimed.add(chestLocation)) {
            player.sendMessage(color(getConfig().getString("messages.prefix", "") + getConfig().getString("messages.already-claimed", "")));
            return true;
        }
        economy.depositPlayer(player, amount);
        String message = getConfig().getString("messages.opened", "").replace("{amount}", String.format(Locale.US, "%.2f", amount));
        player.sendMessage(color(getConfig().getString("messages.prefix", "") + message));
        return true;
    }


    private void cancelTasks() {
        stopAutomatic();
        if (effectTask != null) effectTask.cancel();
        effectTask = null;
    }


    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(color(getConfig().getString("messages.prefix", "") + getConfig().getString("messages.help", "")));
            return true;
        }
        if (!sender.hasPermission("mysterydrop.admin")) {
            send(sender, "no-permission");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "spawn" -> spawnDrop();
            case "start" -> startAutomatic();
            case "stop" -> {
                stopAutomatic();
                send(sender, "stopped");
            }
            case "reload" -> {
                reloadConfig();
                setupEconomy();
                send(sender, "reloaded");
            }
            default -> send(sender, "usage");
        }
        return true;
    }
}
