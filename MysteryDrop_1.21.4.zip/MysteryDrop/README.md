# MysteryDrop
A Paper 1.21.4 plugin that spawns configurable loot chests around world spawn.


## Features
- Manual drop: `/mysterydrop spawn`
- Automatic drops: `/mysterydrop start` and `/mysterydrop stop`
- Countdown broadcast and notification sounds
- Randomized location around world spawn
- Configurable loot item chances
- Optional Vault cash reward for the first player who opens each drop
- Particle effects, configurable chest name, and timed cleanup
- `/mysterydrop reload` and `/mysterydrop help`

## Requirements
- Paper 1.21.4
- Java 21
- Vault + a compatible economy plugin for cash rewards (optional)

## Build
Use Gradle 8.8+ with Java 21:
`gradle build`
The jar is output in `build/libs/`.

## Permissions
- `mysterydrop.admin` (default: OP)


## Configuration
Edit `plugins/MysteryDrop/config.yml`. The `settings.world` value can be left blank to use the first loaded world. `settings.radius` sets the random radius from that world's spawn. Set `settings.money-reward` to `0` to disable money reward.
